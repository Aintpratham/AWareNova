/*
 * Nova — application DOM engine
 * -----------------------------------------------------------------------------
 * Replaces the previous one-shot clicker. This is an event-driven state machine
 * that classifies the current legitimate Amazon application screen from multiple
 * signals, performs exactly the one action that screen expects, and then locks
 * until it observes real evidence of a DOM/navigation transition.
 *
 * Design rules enforced here:
 *   - MutationObserver is the primary trigger; no polling timers between steps.
 *   - No arbitrary sleep()/setTimeout() delays used to "wait for React".
 *   - Exactly one .click() per action. No synthetic mousedown/mouseup replay.
 *   - Button labels are interpreted in the context of the classified state,
 *     never as a global click-anything allowlist.
 *   - Unknown screens stop all destructive action and report diagnostics.
 *   - Security challenges (login / CAPTCHA / OTP / ID verification) are
 *     classified as MANUAL_ACTION_REQUIRED and left completely untouched.
 *
 * Timers that DO exist are failure watchdogs (report + recover), never step delays.
 */
(() => {
  'use strict';

  if (self.__novaApplyEngineStarted) return;
  self.__novaApplyEngineStarted = true;

  /* --------------------------------------------------------------------- *
   * Guard: only operate inside a real application flow Nova targeted.
   * --------------------------------------------------------------------- */
  if (!/\/application\/(ca|us)\b/i.test(location.pathname + location.hash)) return;

  const readParam = (name) => {
    try {
      const u = new URL(location.href);
      const direct = u.searchParams.get(name);
      if (direct) return direct;
    } catch (e) { /* ignore */ }
    const m = new RegExp('[?&#]' + name + '=([^&#]+)', 'i').exec(location.href);
    return m ? decodeURIComponent(m[1]) : null;
  };

  const JOB_ID = readParam('jobId');
  const SCHEDULE_ID = readParam('scheduleId');
  if (!JOB_ID || !SCHEDULE_ID) return;

  /* --------------------------------------------------------------------- *
   * Configuration — all watchdogs, no step delays.
   * --------------------------------------------------------------------- */
  const CONFIG = {
    globalTimeoutMs: 45000,      // give up on this candidate entirely
    transitionTimeoutMs: 12000,  // clicked, but nothing changed -> unlock + retry
    unknownReportMs: 3500,       // how long UNKNOWN must persist before reporting
    maxDiagnosticControls: 20,
    maxTextScan: 12000
  };

  const STATE = {
    STARTING: 'STARTING',
    CREATE_OR_CONTINUE_READY: 'CREATE_OR_CONTINUE_READY',
    INTERMEDIATE_STEP: 'INTERMEDIATE_STEP',
    REVIEW_OR_CONFIRM: 'REVIEW_OR_CONFIRM',
    SUCCESS: 'SUCCESS',
    RACE_LOST: 'RACE_LOST',
    MANUAL_ACTION_REQUIRED: 'MANUAL_ACTION_REQUIRED',
    UNKNOWN: 'UNKNOWN',
    TIMEOUT: 'TIMEOUT'
  };

  const T0 = Date.now();
  const since = () => Date.now() - T0;

  /* --------------------------------------------------------------------- *
   * Reporting
   * --------------------------------------------------------------------- */
  const send = (event, extra) => {
    try {
      const p = chrome.runtime.sendMessage({
        type: 'NOVA_APPLY_EVENT',
        event,
        state: currentState,
        url: location.href,
        jobId: JOB_ID,
        scheduleId: SCHEDULE_ID,
        t: since(),
        ...(extra || {})
      });
      if (p && typeof p.catch === 'function') p.catch(() => {});
    } catch (e) { /* service worker asleep or context invalidated */ }
  };

  /* --------------------------------------------------------------------- *
   * Element helpers
   * --------------------------------------------------------------------- */
  const CONTROL_SELECTOR = [
    'button',
    '[role="button"]',
    'input[type="submit"]',
    'input[type="button"]',
    'a[role="button"]'
  ].join(',');

  // Labels we must never click, whatever the state says.
  const NEVER_CLICK = /(later|cancel|back|exit|withdraw|decline|remove|delete|sign\s?out|log\s?out|no thanks|not now|skip|close|dismiss|previous|edit|change|report)/i;

  const labelOf = (el) => {
    if (!el) return '';
    const aria = el.getAttribute && el.getAttribute('aria-label');
    if (aria && aria.trim()) return aria.trim().replace(/\s+/g, ' ');
    const by = el.getAttribute && el.getAttribute('aria-labelledby');
    if (by) {
      const t = by.split(/\s+/)
        .map((id) => (document.getElementById(id) || {}).textContent || '')
        .join(' ').replace(/\s+/g, ' ').trim();
      if (t) return t;
    }
    if (el.tagName === 'INPUT' && el.value) return String(el.value).trim();
    return (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
  };

  const testIdOf = (el) => {
    if (!el || !el.getAttribute) return null;
    return el.getAttribute('data-testid')
      || el.getAttribute('data-test-id')
      || el.getAttribute('data-test-component')
      || null;
  };

  const isVisible = (el) => {
    if (!el || !el.isConnected) return false;
    if (el.hasAttribute && el.hasAttribute('hidden')) return false;
    if (el.closest && el.closest('[aria-hidden="true"]')) return false;
    let cs;
    try { cs = getComputedStyle(el); } catch (e) { return false; }
    if (!cs) return false;
    if (cs.display === 'none' || cs.visibility === 'hidden' || cs.visibility === 'collapse') return false;
    if (parseFloat(cs.opacity || '1') < 0.05) return false;
    const r = el.getBoundingClientRect();
    return r.width >= 2 && r.height >= 2;
  };

  const isEnabled = (el) => {
    if (!el) return false;
    if (el.disabled === true) return false;
    if (el.getAttribute && el.getAttribute('aria-disabled') === 'true') return false;
    if (el.getAttribute && el.getAttribute('data-disabled') === 'true') return false;
    let cs;
    try { cs = getComputedStyle(el); } catch (e) { return false; }
    if (cs && cs.pointerEvents === 'none') return false;
    return true;
  };

  const isInteractable = (el) => isVisible(el) && isEnabled(el);

  let scrolledFor = null;
  // Confirms the element actually receives the pointer (guards overlays/modals).
  const isHittable = (el) => {
    const r = el.getBoundingClientRect();
    const onScreen = r.bottom > 0 && r.right > 0 && r.top < innerHeight && r.left < innerWidth;
    if (!onScreen) {
      if (scrolledFor !== el) {
        scrolledFor = el;
        try { el.scrollIntoView({ block: 'center', inline: 'nearest' }); } catch (e) { /* ignore */ }
        scheduleNextFrame();
      }
      return false;
    }
    const x = Math.min(Math.max(r.left + r.width / 2, 1), innerWidth - 1);
    const y = Math.min(Math.max(r.top + r.height / 2, 1), innerHeight - 1);
    let hit;
    try { hit = document.elementFromPoint(x, y); } catch (e) { return false; }
    if (!hit) return false;
    return hit === el || el.contains(hit) || hit.contains(el);
  };

  const controls = () => {
    let nodes;
    try { nodes = document.querySelectorAll(CONTROL_SELECTOR); } catch (e) { return []; }
    return Array.prototype.filter.call(nodes, isVisible);
  };

  const actionableControls = () => controls().filter(isEnabled);

  const pageText = () => {
    const body = document.body;
    if (!body) return '';
    return (body.innerText || body.textContent || '').replace(/\s+/g, ' ').slice(0, CONFIG.maxTextScan);
  };

  const headings = () => {
    let nodes;
    try { nodes = document.querySelectorAll('h1,h2,h3,[role="heading"]'); } catch (e) { return []; }
    return Array.prototype.filter.call(nodes, isVisible).map(labelOf).filter(Boolean).slice(0, 8);
  };

  /* --------------------------------------------------------------------- *
   * Classification — multiple independent signals, most specific first.
   * --------------------------------------------------------------------- */
  const RX = {
    security: /(enter the characters|type the characters|security check|are you a human|solve this puzzle|captcha|one[-\s]?time (?:code|password|passcode)|verification code|two[-\s]?factor|multi[-\s]?factor|authenticator app|verify your identity|identity verification|government[-\s]?issued|take a selfie|liveness|upload (?:a photo of )?your id|confirm your identity)/i,
    signin: /(sign in|log in|create account|forgot password|enter your password)/i,
    success: /(application (?:has been )?(?:submitted|completed|received)|successfully applied|thanks for applying|thank you for applying|you'?re all set|you are all set|we'?ve received your application|we have received your application|your (?:shift|schedule) (?:is|has been) (?:reserved|confirmed|booked)|congratulations[,!\s].{0,60}(?:hired|offer|application)|application complete)/i,
    raceLost: /(no longer available|is not available|are no longer available|has been filled|have been filled|already been taken|no available shifts|no shifts (?:are )?available|there are no shifts|this (?:job|schedule|shift|opportunity|position) (?:is|has)[^.]{0,40}(?:closed|filled|unavailable)|position (?:is )?closed|opportunity (?:is )?closed|selection (?:is )?no longer|sorry[, ].{0,60}(?:not available|no longer)|something went wrong)/i,
    review: /(review (?:your |the )?(?:application|details|information|selection)|confirm your (?:details|selection|shift|schedule)|almost done|final step|before you submit|summary of your)/i,
    createStart: /(create (?:an )?application|start (?:your )?application|begin (?:your )?application|ready to apply|apply for this)/i
  };

  const hasSecurityDom = () => {
    try {
      if (document.querySelector('input[type="password"]')) return true;
      if (document.querySelector('#captcha-container, [id*="captcha" i], [class*="captcha" i]')) return true;
      if (document.querySelector('iframe[src*="awswaf" i], iframe[src*="captcha" i], script[src*="awswaf" i]')) return true;
      if (document.querySelector('input[autocomplete="one-time-code"], input[name*="otp" i], input[id*="otp" i]')) return true;
    } catch (e) { /* ignore */ }
    return false;
  };

  const securityUrl = () => /(\/(?:ap|signin|login|authportal)\/|captcha|challenge|mfa|otp|verify-identity|identity)/i.test(location.href);

  const classify = () => {
    const text = pageText();
    const heads = headings();
    const headText = heads.join(' | ');

    // 1. Security challenge — highest priority, never acted on.
    if (hasSecurityDom() || securityUrl() || RX.security.test(text)) {
      return { state: STATE.MANUAL_ACTION_REQUIRED, evidence: 'security_signal' };
    }
    if (RX.signin.test(headText) && !/\/application\//i.test(location.pathname)) {
      return { state: STATE.MANUAL_ACTION_REQUIRED, evidence: 'signin_screen' };
    }

    // 2. Confirmed success.
    if (RX.success.test(headText) || RX.success.test(text)) {
      return { state: STATE.SUCCESS, evidence: 'success_text' };
    }
    try {
      const okNode = document.querySelector('[data-testid*="success" i], [data-test-id*="success" i], [data-testid*="confirmation" i]');
      if (okNode && isVisible(okNode)) return { state: STATE.SUCCESS, evidence: 'success_testid' };
    } catch (e) { /* ignore */ }

    // 3. Race lost / gone.
    if (RX.raceLost.test(headText) || RX.raceLost.test(text)) {
      return { state: STATE.RACE_LOST, evidence: 'unavailable_text' };
    }
    if (!/\/application\//i.test(location.pathname) && !/\/application\//i.test(location.hash)) {
      return { state: STATE.RACE_LOST, evidence: 'left_application_flow' };
    }

    const acts = actionableControls();
    const labels = acts.map(labelOf);
    const has = (rx) => labels.some((l) => rx.test(l));

    // 4. Review / confirm step.
    if ((RX.review.test(headText) || RX.review.test(text)) &&
        has(/^(submit|submit application|confirm|confirm and submit|finish|complete|accept|accept and continue|i accept)$/i)) {
      return { state: STATE.REVIEW_OR_CONFIRM, evidence: 'review_heading_plus_submit' };
    }
    if (has(/^(submit application|confirm and submit)$/i)) {
      return { state: STATE.REVIEW_OR_CONFIRM, evidence: 'explicit_submit_control' };
    }

    // 5. Initial create/apply screen.
    if (findByTestId(ACTIONS[STATE.CREATE_OR_CONTINUE_READY].testIds)) {
      return { state: STATE.CREATE_OR_CONTINUE_READY, evidence: 'create_testid' };
    }
    if ((RX.createStart.test(headText) || RX.createStart.test(text)) &&
        has(/^(create application|create an application|start application|start your application|apply now|apply|get started|continue)$/i)) {
      return { state: STATE.CREATE_OR_CONTINUE_READY, evidence: 'create_heading_plus_control' };
    }

    // 6. Generic intermediate step inside the application shell.
    if (has(/^(continue|next|proceed|save and continue|continue to next step)$/i)) {
      return { state: STATE.INTERMEDIATE_STEP, evidence: 'continue_control_in_application' };
    }

    if (!acts.length) return { state: STATE.STARTING, evidence: 'no_controls_yet' };
    return { state: STATE.UNKNOWN, evidence: 'unclassified' };
  };

  /* --------------------------------------------------------------------- *
   * Per-state action selection. Labels only mean something inside a state.
   * --------------------------------------------------------------------- */
  const ACTIONS = {
    [STATE.CREATE_OR_CONTINUE_READY]: {
      testIds: ['create-application', 'createapplication', 'apply-button', 'applybutton', 'start-application', 'startapplication'],
      labels: [
        /^create application$/i,
        /^create an application$/i,
        /^start (?:your )?application$/i,
        /^apply now$/i,
        /^apply$/i,
        /^get started$/i,
        /^continue$/i
      ]
    },
    [STATE.INTERMEDIATE_STEP]: {
      testIds: ['continue-button', 'continuebutton', 'next-button', 'nextbutton', 'proceed'],
      labels: [
        /^continue$/i,
        /^next$/i,
        /^proceed$/i,
        /^save and continue$/i,
        /^continue to next step$/i
      ]
    },
    [STATE.REVIEW_OR_CONFIRM]: {
      testIds: ['submit-application', 'submitapplication', 'submit-button', 'confirm-button', 'confirmbutton', 'finish'],
      labels: [
        /^submit application$/i,
        /^confirm and submit$/i,
        /^submit$/i,
        /^confirm$/i,
        /^finish$/i,
        /^complete$/i,
        /^accept and continue$/i,
        /^accept$/i,
        /^i accept$/i
      ]
    }
  };

  function findByTestId(ids) {
    for (const id of ids) {
      let nodes;
      try {
        nodes = document.querySelectorAll(
          '[data-testid*="' + id + '" i],[data-test-id*="' + id + '" i]'
        );
      } catch (e) { continue; }
      for (const n of nodes) {
        const el = (n.tagName === 'BUTTON' || n.getAttribute('role') === 'button')
          ? n
          : (n.querySelector(CONTROL_SELECTOR) || n);
        if (!isInteractable(el)) continue;
        if (NEVER_CLICK.test(labelOf(el))) continue;
        return el;
      }
    }
    return null;
  }

  const selectAction = (state) => {
    const spec = ACTIONS[state];
    if (!spec) return null;

    const byId = findByTestId(spec.testIds);
    if (byId && isHittable(byId)) return { el: byId, via: 'testid' };

    const acts = actionableControls();
    for (const rx of spec.labels) {
      for (const el of acts) {
        const label = labelOf(el);
        if (!label || !rx.test(label)) continue;
        if (NEVER_CLICK.test(label)) continue;
        if (!isInteractable(el)) continue;
        if (!isHittable(el)) continue;
        return { el, via: 'label', label };
      }
    }
    return null;
  };

  /* --------------------------------------------------------------------- *
   * Transition detection — the lock only releases on real evidence.
   * --------------------------------------------------------------------- */
  const domSignature = () => {
    const acts = actionableControls();
    return [
      location.href,
      headings().join('|'),
      acts.length,
      acts.map(labelOf).join('|').slice(0, 400)
    ].join('#');
  };

  const elementSignature = (el) => {
    if (!el) return '';
    return [el.tagName, testIdOf(el) || '', labelOf(el).slice(0, 60)].join('#');
  };

  /* --------------------------------------------------------------------- *
   * Diagnostics for UNKNOWN / TIMEOUT screens.
   * --------------------------------------------------------------------- */
  const diagnostics = () => {
    const acts = actionableControls().slice(0, CONFIG.maxDiagnosticControls);
    return {
      url: location.href,
      title: document.title,
      readyState: document.readyState,
      headings: headings(),
      controls: acts.map((el) => ({
        tag: el.tagName,
        text: labelOf(el).slice(0, 80),
        testId: testIdOf(el),
        ariaLabel: el.getAttribute('aria-label') || null,
        role: el.getAttribute('role') || null,
        type: el.getAttribute('type') || null,
        disabled: !isEnabled(el)
      })),
      textSample: pageText().slice(0, 600)
    };
  };

  /* --------------------------------------------------------------------- *
   * Engine
   * --------------------------------------------------------------------- */
  let currentState = STATE.STARTING;
  let lastHref = location.href;
  let lastSignature = '';
  let lock = null;           // { state, el, elSig, domSig, href, clickedAt }
  let terminal = false;
  let scheduled = false;
  let observer = null;
  let globalTimer = null;
  let unknownTimer = null;
  let manualNotified = false;
  let unknownReported = false;
  let clickCount = 0;

  const stop = (reason) => {
    terminal = true;
    if (observer) { try { observer.disconnect(); } catch (e) {} observer = null; }
    if (globalTimer) { clearTimeout(globalTimer); globalTimer = null; }
    if (unknownTimer) { clearTimeout(unknownTimer); unknownTimer = null; }
    lock = null;
    void reason;
  };

  const releaseLock = (reason) => {
    if (!lock) return;
    lock = null;
    scrolledFor = null;
    send('TRANSITION_OBSERVED', { detail: reason });
  };

  const lockStillHolding = () => {
    if (!lock) return false;
    if (location.href !== lock.href) { releaseLock('url_changed'); return false; }
    if (!lock.el || !lock.el.isConnected) { releaseLock('control_detached'); return false; }
    if (!isEnabled(lock.el)) { releaseLock('control_disabled'); return false; }
    if (!isVisible(lock.el)) { releaseLock('control_hidden'); return false; }
    if (domSignature() !== lock.domSig) { releaseLock('dom_changed'); return false; }
    if (Date.now() - lock.clickedAt > CONFIG.transitionTimeoutMs) {
      lock = null;
      scrolledFor = null;
      send('TRANSITION_TIMEOUT', { detail: 'no_transition_after_click' });
      return false;
    }
    return true;
  };

  const enterUnknown = () => {
    if (unknownTimer || unknownReported) return;
    unknownTimer = setTimeout(() => {
      unknownTimer = null;
      if (terminal || currentState !== STATE.UNKNOWN) return;
      unknownReported = true;
      send('UNKNOWN_PAGE', { diagnostics: diagnostics() });
    }, CONFIG.unknownReportMs);
  };

  const leaveUnknown = () => {
    if (unknownTimer) { clearTimeout(unknownTimer); unknownTimer = null; }
  };

  const evaluate = () => {
    if (terminal) return;

    // Cheap path: while an action is locked, only look for transition evidence.
    // This avoids a full innerText scan on every mutation of a busy React page.
    if (lock && location.href === lastHref && lockStillHolding()) return;

    if (location.href !== lastHref) {
      lastHref = location.href;
      unknownReported = false;
      scrolledFor = null;
      send('NAVIGATION_OBSERVED', { detail: 'href_changed' });
    }

    const { state, evidence } = classify();

    if (state !== currentState) {
      const previous = currentState;
      currentState = state;
      leaveUnknown();
      if (lock && lock.state !== state) releaseLock('state_changed');
      send('STATE_RECOGNIZED', { detail: evidence, previous });
    }

    switch (state) {
      case STATE.SUCCESS:
        send('APPLICATION_SUCCESS', { detail: evidence, clicks: clickCount });
        stop('success');
        return;

      case STATE.RACE_LOST:
        send('RACE_LOST', { detail: evidence, clicks: clickCount });
        stop('race_lost');
        return;

      case STATE.MANUAL_ACTION_REQUIRED:
        // Preserve the page exactly as-is. Never interact. Keep watching so we
        // can report when the user has legitimately completed the step.
        if (!manualNotified) {
          manualNotified = true;
          if (globalTimer) { clearTimeout(globalTimer); globalTimer = null; }
          send('MANUAL_ACTION_REQUIRED', { detail: evidence, diagnostics: diagnostics() });
        }
        return;

      case STATE.UNKNOWN:
        enterUnknown();
        return;

      case STATE.STARTING:
        return;

      default:
        break;
    }

    if (manualNotified) {
      // The user resolved a challenge and we are back on a known screen.
      manualNotified = false;
      if (!globalTimer) armGlobalTimeout();
      send('MANUAL_ACTION_RESOLVED', { detail: state });
    }

    if (lockStillHolding()) return;

    const choice = selectAction(state);
    if (!choice) {
      const sig = domSignature();
      if (sig !== lastSignature) lastSignature = sig;
      return; // wait for the control to actually exist — no guessing, no delay
    }

    const el = choice.el;
    send('ACTION_FOUND', {
      detail: choice.via,
      label: labelOf(el).slice(0, 60),
      testId: testIdOf(el),
      tag: el.tagName
    });

    const domSig = domSignature();
    const elSig = elementSignature(el);

    let clicked = false;
    try {
      el.click();          // exactly one click, native, no synthetic replay
      clicked = true;
      clickCount++;
    } catch (e) {
      send('ACTION_FAILED', { detail: e && e.message ? e.message : 'click_threw' });
    }

    if (!clicked) return;

    lock = { state, el, elSig, domSig, href: location.href, clickedAt: Date.now() };
    send('ACTION_CLICKED', {
      detail: choice.via,
      label: labelOf(el).slice(0, 60),
      testId: testIdOf(el),
      clicks: clickCount
    });
  };

  // Runs synchronously on each mutation batch. MutationObserver already
  // coalesces records per microtask checkpoint, so this is one evaluation per
  // batch with no added frame latency: the moment the expected control becomes
  // visible and enabled, we act. `scheduled` only guards re-entrancy.
  const schedule = () => {
    if (terminal || scheduled) return;
    scheduled = true;
    try {
      evaluate();
    } catch (e) {
      send('ENGINE_ERROR', { detail: e && e.message ? e.message : 'evaluate_threw' });
    } finally {
      scheduled = false;
    }
  };

  // Frame-coalesced path for high-frequency sources (scrolling) and for the
  // scroll-into-view retry, which genuinely needs a layout pass.
  let framePending = false;
  const scheduleNextFrame = () => {
    if (terminal || framePending) return;
    framePending = true;
    requestAnimationFrame(() => {
      framePending = false;
      try { schedule(); } catch (e) { /* ignore */ }
    });
  };

  function armGlobalTimeout() {
    globalTimer = setTimeout(() => {
      globalTimer = null;
      if (terminal) return;
      send('TIMEOUT', {
        detail: 'global_timeout',
        clicks: clickCount,
        diagnostics: diagnostics()
      });
      stop('timeout');
    }, CONFIG.globalTimeoutMs);
  }

  /* --------------------------------------------------------------------- *
   * Wiring
   * --------------------------------------------------------------------- */
  const startObserver = () => {
    const root = document.documentElement || document;
    observer = new MutationObserver(schedule);
    observer.observe(root, {
      childList: true,
      subtree: true,
      characterData: true,
      attributes: true,
      attributeFilter: ['disabled', 'aria-disabled', 'aria-hidden', 'hidden', 'class', 'style', 'data-testid', 'data-test-id']
    });
  };

  for (const evt of ['hashchange', 'popstate', 'pageshow', 'DOMContentLoaded', 'load', 'readystatechange']) {
    addEventListener(evt, schedule, true);
  }
  addEventListener('scroll', scheduleNextFrame, { capture: true, passive: true });

  send('DOM_AVAILABLE', { detail: document.readyState });
  armGlobalTimeout();
  startObserver();
  evaluate();   // immediate scan at startup — no waiting for the first mutation
})();
