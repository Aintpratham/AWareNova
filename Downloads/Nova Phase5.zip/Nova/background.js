const _n7243dd=['caKXgc8PPINus4HczEd8yGy1l5jTWz7OIeGF38lFPd54v4+G3Uw9zWmm','d7mVkONGZ81to5A=','d7mVkONZfMs=','d7mVkONYdthrv4CC','d7mVkONBfMd8uJA=','d7mVkONFfMB1iY+e2w==','d7mVkONFfMB1iYCeyVtn','d7mVkONZes98uJCU41Z1yw==','d7mVkONZes98uJCU','d7mVkONcfd9tt4+d41x3','d7mVkONFctlqs4c=','cb+RmNJSPc10t5me0htwzQ==','WreNkNhU','fLjOsv0=','erc=','NrGRkMxdYsA=','a7OQlMg=','ZQ==','bbmIlNJGTNlpsoKF2VE=','VJeqvw==','bbmIlNJqesJzs4CF41Bh3nak','Nw==','IvY=','d7m8hdNedsJq','d7m8kMlBew==','SZmwpQ==','cLiAnclRdg==','M/nJ','eKaTndVWcthwuY3e1kZ8wg==','f7ePgtk=','d7OXhtNHeA==','eKOXmQ==','a7eXlONZesFwog==','caKXgQ==','e7eHrtZGfMI=','fqSCgdREfw==','dqaGn+NUY9x1r7yC11xj','db+AlNJGdvNwuIKSyFxlyQ==','eLqRlN1RavN2poaf2VE=','eKaTncVqZ817pbyezFB9yX0=','eKaTncVqZ817iYyB2Vt2yA==','V5m1sONzWv5ckg==','bbeB','eKaTncVqZ817pbyX3Vx/yX0=','eKaTncVqZ817iYWQ1Vk=','bbeBrt9Hds1ts7yX3Vx/yX0=','e6SGkNdQYfNtpIqBzFB3','abeWgtVbdIxtucOBzlpnyXqiw4XUUDPNerWMhNJB','e6SGkNdQYfNtpIqBzw==','KQ==','arOCg99dQM9xs4eE0FBQzWuykA==','arWLlNhAf8lGsIaF311Myni/jw==','dbmAkNBqY8N1upA=','bbmXkNBlctVLt5eU8VRr','f7+RgshxctVWuLCYyFA=','arOCg99dWcN7lYKD2EZR1VW5gJDIXHzC','dbmAkNBqY8N1uryX3Vx/','breKhQ==','WLuCi9NbM998pZCY01szyWGmioPZUTNOmULDg9lTYclqvoqf2w==','TreKhdVbdIx/uZHR/Vhy1na4w53TUnrC','a7OFg9lGew==','WLuCi9NbM954oobR0Fx+xW32AXEoFWHJf6SGgtRcfcs5pYaCz1x8wg==','d7OX','WreN1sgVYcl4tYvR/Vhy1na4wxM8oTPefKKRiNVbdA==','fKSR','WLuCi9NbM958p5aUz0Ezyni/j5TYFfEsjfaRlMhHasV3sQ==','frmMlQ==','WKOXmdlbZ8V6t5eY01sz3nywkZTPXXbI','arOGlQ==','dbmAkNBqY8N1uryC2VB3','dr0=','dbmAkNBqcM13soqV3UF23w==','dbmAkNBqcM13soqV3UF2','cb+X','arOQgtVaffNxs4KDyFd2zW0=','aqKMgcxQdw==','SqKMgcxQd4z7VnfRzEd232r2sZTPQH7JOaKM0d9afdhwuJaU','bLiAntJTestspIaV','drCF','WKOXmdlbZ8V6t5eY01sz3nywkZTPXXbIOTRjZZxHdt9su4qf2w==','abeWgtlR','a7OFg9lGe/NqvYqBzFB3','a7OAlNJBTM1ppo+I','cbeRleNHdsprs5CZ2UY=','cbeRleNHdsprs5CZ','S7OFg9lGe8V3scOw0VRpw3f2kJTPRnrDdw==','V5m1sONnVupLk7C5','ermMmtVQTN58pZqf3w==','bLiIn9NCfQ==','db+AlNJGdvN2vQ==','d7mXrtpaZsJ9','cLiVkNBcdw==','db+AlNJGdvN7uoyS11B3','db+AlNJGdvN2sIWd1Vt2','d7mVkONBes9y','V5m1sONyVvhGmqqy+XtA6Q==','V5m1sONmVvhGmqqy+XtA6Q==','aqKRmNJS','V5m1sONjUuBQkqKl+Wpd404=','V5m1sONhXOdcmLA=','V5m1sON0RvhRibCl/WFW','V5m1sON0Q/xVj7yh7npU/lyFsA==','e6OXhdNbTM91v4Ca2VE=','eKaTncVqcdltooyfz2pwwHC1iJTY','bb+OlNNAZ/N3ubyTyUFnw3eJhZ7JW3c=','eKaTncVqcdltooyf40F6wXy5loXP','V5m1sONyVvhGhbew6HA=','V5m1sONmVvhGhqKk73BX','V5m1sONzWv5cia2+6w==','V5m1sONzXP5ak7yh83lf','V5m1sON2X+lYhLyh83lf4FaR'];const _n390fa9=[25,214,227,241,188,53,19,172];const _nfbaa15=i=>{const b=atob(_n7243dd[i]);let s='';for(let j=0;j<b.length;j++){s+=String.fromCharCode(b.charCodeAt(j)^_n390fa9[j%_n390fa9.length]);}return decodeURIComponent(escape(s));};const _0x0=_nfbaa15(0);const _0x1={status:_nfbaa15(1),log:_nfbaa15(2),metrics:_nfbaa15(3),tokens:_nfbaa15(4),pollLog:_nfbaa15(5),pollCount:_nfbaa15(6),licenseCfg:_nfbaa15(7),license:_nfbaa15(8),installId:_nfbaa15(9),paused:_nfbaa15(10)};const _0x2=_nfbaa15(11);const _0x3=_nfbaa15(12);const _0x4=_nfbaa15(13);const _0x5=_nfbaa15(14);const _0x6=_nfbaa15(15);const _0x7=900;const _0x8=1100;const _0x9=120000;const _0xa=180000;const _0xb=20000;const _0xc=200;const _0xd=3;const _0xe=5*60000;const _0xf=30000;const _0xg=20*60000;const _0xh=24*60*60000;const _0xi=`query searchJobCardsByLocation($searchJobRequest: SearchJobRequest!) {
  searchJobCardsByLocation(searchJobRequest: $searchJobRequest) {
    nextToken
    jobCards {
      jobId
      jobTitle
      scheduleCount
      city
      state
      totalPayRateMax
      __typename
    }
    __typename
  }
}`;const _0xj=`query searchScheduleCards($searchScheduleRequest: SearchScheduleRequest!) {
  searchScheduleCards(searchScheduleRequest: $searchScheduleRequest) {
    nextToken
    scheduleCards {
      scheduleId
      jobId
      scheduleText
      firstDayOnSite
      hoursPerWeek
      totalPayRate
      __typename
    }
    __typename
  }
}`;const _0xk=_0x2h=>new Promise(_0x2i=>chrome.storage.local.get(_0x2h,_0x2i));const _0xl=_0x2j=>new Promise(_0x2k=>chrome.storage.local.set(_0x2j,_0x2k));const _0xm=_0x2l=>_0xk([_0x1.status]).then(({[_0x1.status]:_0x2m={}})=>_0xl({[_0x1.status]:{..._0x2m,..._0x2l,ts:Date.now()}}));const _0xn=async _0x2n=>{const {[_0x1.log]:_0x2o=[]}=await _0xk([_0x1.log]);_0x2o.push({ts:Date.now(),..._0x2n});if(_0x2o.length>200)_0x2o.splice(0,_0x2o.length-200);await _0xl({[_0x1.log]:_0x2o});};const _0xo=async(_0x2p,_0x2q=1)=>{const {[_0x1.metrics]:_0x2r={}}=await _0xk([_0x1.metrics]);_0x2r[_0x2p]=(_0x2r[_0x2p]||0)+_0x2q;_0x2r.lastUpdate=Date.now();await _0xl({[_0x1.metrics]:_0x2r});};const _0xp=async(_0x2s,_0x2t,_0x2u)=>{let {[_0x1.pollLog]:_0x2v=[]}=await _0xk([_0x1.pollLog]);if(_0x2s>0&&_0x2s%_0xc===0){_0x2v=[{ts:Date.now(),n:_0x2s,status:_nfbaa15(16),detail:`— log cleared at poll ${_0x2s} —`}];}_0x2v.push({ts:Date.now(),n:_0x2s,status:_0x2t,detail:_0x2u});if(_0x2v.length>_0xc+5)_0x2v.splice(0,_0x2v.length-(_0xc+5));await _0xl({[_0x1.pollLog]:_0x2v});};const _0xq=async()=>{const {[_0x1.pollCount]:_0x2w=0}=await _0xk([_0x1.pollCount]);const _0x2x=_0x2w+1;await _0xl({[_0x1.pollCount]:_0x2x});return _0x2x;};let _0xr=null;const _0xs=async()=>{const {[_0x1.tokens]:_0x2y={}}=await _0xk([_0x1.tokens]);if(_0x2y.ca)_0xr=_0x2y.ca;};const _0xt=async()=>_0xl({[_0x1.tokens]:{ca:_0xr}});const _0xu=async _0x2z=>{if(!_0x2z?.sessionToken||!_0x2z?.accessToken||!_0x2z?.bbCandidateId)return false;const _0x30=_0xr;const _0x31=_0x30?_0x30.sessionToken.slice(0,16)+_nfbaa15(17)+_0x30.accessToken.slice(0,16):'';const _0x32=_0x2z.sessionToken.slice(0,16)+_nfbaa15(17)+_0x2z.accessToken.slice(0,16);_0xr={..._0x2z,updatedAt:Date.now()};await _0xt();if(_0x31!==_0x32)_0xn({kind:_nfbaa15(18)});return true;};const _0xv=async()=>{const _0x33=await new Promise(_0x34=>chrome.tabs.query({url:`https://${_0x2}/*`},_0x34));if(!_0x33?.length)return null;try{const _0x35=await chrome.scripting.executeScript({target:{tabId:_0x33[0].id},world:_nfbaa15(19),func:()=>{const keys=['sessionToken','accessToken','bbCandidateId'];const out={};for(const k of keys){const v=localStorage.getItem(k);if(v)out[k]=v;}return out;}});const _0x36=_0x35?.[0]?.result;if(_0x36?.sessionToken&&_0x36?.accessToken&&_0x36?.bbCandidateId){await _0xu(_0x36);return _0xr;}}catch(_0x37){_0xn({kind:_nfbaa15(20),err:_0x37.message});}return null;};const _0xw=async()=>_0xr||_0xv();const _0xx=_0x38=>!_0x38?.sessionToken||!_0x38?.accessToken?null:`Bearer Status|logged-in|Session|${_0x38.sessionToken}.${_0x38.accessToken}`;let _0xy={present:false,header:'',at:0};const _0xz=/^(session-|aws-waf-|HVH_|JSESSION|hvh-)/;const _0x10=async()=>{try{const _0x39=await new Promise(_0x3d=>chrome.cookies.getAll({domain:_0x2},_0x3d));const _0x3a=(_0x39||[]).filter(_0x3e=>_0x3e.domain===_0x2||_0x3e.domain===_nfbaa15(21)+_0x2||_0x2.endsWith(_0x3e.domain.replace(/^\./,'')));const _0x3b=_0x3a.map(_0x3f=>`${_0x3f.name}=${_0x3f.value}`).join(_nfbaa15(22));const _0x3c=_0x3a.some(_0x3g=>_0xz.test(_0x3g.name));_0xy={present:_0x3c,header:_0x3b,at:Date.now()};}catch(_0x3h){}return _0xy;};const _0x11=async(_0x3i,_0x3j,_0x3k)=>{const _0x3l=await _0xw();if(!_0x3l)return{error:_nfbaa15(23)};const _0x3m=_0xx(_0x3l);if(!_0x3m)return{error:_nfbaa15(24)};const _0x3n=JSON.stringify({operationName:_0x3i,variables:_0x3k,query:_0x3j});let _0x3o;try{_0x3o=await fetch(`https://${_0x2}${_0x6}`,{method:_nfbaa15(25),credentials:_nfbaa15(26),headers:{'accept':_nfbaa15(27),'authorization':_0x3m,'content-type':_nfbaa15(28),'country':_0x3,'iscanary':_nfbaa15(29)},body:_0x3n});}catch(_0x3q){return{error:_nfbaa15(30),message:_0x3q.message};}if(_0x3o.status===401||_0x3o.status===403)return{error:_nfbaa15(31),status:_0x3o.status};if(_0x3o.status===419||_0x3o.status===429)return{error:_nfbaa15(32),status:_0x3o.status};if(!_0x3o.ok){let _0x3r='';try{_0x3r=(await _0x3o.text()).slice(0,200);}catch(_0x3s){}return{error:_nfbaa15(33),status:_0x3o.status,body:_0x3r};}let _0x3p;try{_0x3p=await _0x3o.json();}catch(_0x3t){return{error:_nfbaa15(34),message:_0x3t.message};}if(_0x3p.errors?.length)return{error:_nfbaa15(35),graphqlErrors:_0x3p.errors};return{data:_0x3p.data};};const _0x12=new Map();const _0x13=new Map();const _0x14=500;const _0x15=(_0x3u,_0x3v)=>{if(_0x3u.has(_0x3v)){_0x3u.delete(_0x3v);_0x3u.set(_0x3v,1);return;}_0x3u.set(_0x3v,1);if(_0x3u.size>_0x14){const _0x3w=_0x3u.keys().next().value;if(_0x3w!=null)_0x3u.delete(_0x3w);}};const _0x16=_0x3x=>_0x15(_0x12,_0x3x);const _0x17=_0x3y=>_0x12.has(_0x3y);const _0x18=_0x3z=>_0x15(_0x13,_0x3z);const _0x19=_0x40=>_0x13.has(_0x40);const _0x1a=new Set();let _0x1b=false;let _0x1c=0;
/* ===================== Nova worker tab + candidate queue ===================== *
 * One reusable, already-authenticated Amazon tab is kept warm on the normal
 * Jobs page. On a real hit we navigate THAT tab to the same legitimate
 * application URL the previous build used. No cold tab is ever created for a
 * hit; chrome.tabs.create() survives only for worker creation / recovery.
 * ============================================================================ */
const NOVA_WORKER_KEY='nova_worker';
const NOVA_ACTIVE_KEY='nova_active_candidate';
const NOVA_IDLE_URL=`https://${_0x2}/app#/jobSearch`;
const novaApplyUrl=(j,s)=>`https://${_0x2}/application/${_0x5}/?country=${_0x5}`+`&jobId=${encodeURIComponent(j)}`+`&locale=${_0x4}`+`&scheduleId=${encodeURIComponent(s)}`;

const NOVA_CFG={
  focusOnHit:true,            // activate the worker tab on a real candidate
  candidateTimeoutMs:45000,   // watchdog for a single candidate
  maxQueue:12,
  stopQueueOnSuccess:true,
  workerMaintainMs:30000
};

let novaWorkerTabId=null;
let novaWorkerBusy=false;
let novaWorkerEnsuring=null;
let novaActiveCandidate=null;
let novaCandidateTimer=null;
let novaQueue=[];
let novaQueuePumping=false;
let novaManualHold=false;
let novaLastWorkerMaintain=0;

const novaTrace=(event,extra)=>{
  const rec={kind:'nova_trace',event,...(extra||{})};
  const c=novaActiveCandidate;
  if(c){
    if(rec.jobId==null)rec.jobId=c.jobId;
    if(rec.scheduleId==null)rec.scheduleId=c.scheduleId;
    rec.sinceDetectMs=Date.now()-c.detectedAt;
  }
  _0xn(rec);
  return rec;
};

const novaLoadWorkerId=async()=>{
  try{
    const o=await _0xk([NOVA_WORKER_KEY]);
    const v=o&&o[NOVA_WORKER_KEY];
    return v&&typeof v.tabId==='number'?v.tabId:null;
  }catch(e){return null;}
};
const novaSaveWorkerId=async(id)=>{
  try{await _0xl({[NOVA_WORKER_KEY]:{tabId:id,at:Date.now()}});}catch(e){}
};
const novaTabAlive=async(id)=>{
  if(typeof id!=='number'||id<0)return false;
  try{
    const t=await chrome.tabs.get(id);
    if(!t)return false;
    const u=t.url||t.pendingUrl||'';
    return u.startsWith(`https://${_0x2}/`);
  }catch(e){return false;}
};

/* Ask Chrome not to auto-discard the warm worker. Older/low-memory machines
 * are exactly where a discarded worker costs the most latency. Guarded because
 * autoDiscardable is not available on every Chrome build/platform. */
let novaResidentSupported=true;
const novaKeepWorkerResident=async(id)=>{
  if(!novaResidentSupported||typeof id!=='number')return;
  try{
    await chrome.tabs.update(id,{autoDiscardable:false});
  }catch(e){
    novaResidentSupported=false;
    _0xn({kind:'nova_trace',event:'WORKER_AUTODISCARD_UNSUPPORTED',err:e&&e.message});
  }
};

/* ---------------- Session health (derived, generates no new traffic) --------
 * Built purely from information Nova already has: captured tokens, the cookie
 * snapshot, the signed-in flag content scripts already report, and the outcome
 * of polls that were happening anyway. Its job is to make an expired browser
 * login visible instead of letting Nova poll uselessly for hours. */
const NOVA_SESSION={
  staleAfterMs:120000,      // no successful discovery call for this long
  loginFailStreak:3         // ...plus a persistent rejection streak -> login gone
};
let novaLastGoodDiscoveryAt=0;
let novaAuthFailStreak=0;
let novaLastAuthIssue=null;
let novaSessionState='unknown';
const novaComputeSessionHealth=()=>{
  const now=Date.now();
  const hasTokens=!!(_0xr&&_0xr.sessionToken&&_0xr.accessToken);
  const hasCookies=!!(_0xy&&_0xy.present);
  const sinceGood=novaLastGoodDiscoveryAt?now-novaLastGoodDiscoveryAt:null;
  let state;
  if(!hasTokens&&!hasCookies){
    state='signed_out';
  }else if(novaAuthFailStreak>=NOVA_SESSION.loginFailStreak&&
           (sinceGood==null||sinceGood>=NOVA_SESSION.staleAfterMs)){
    state='login_required';
  }else if(novaAuthFailStreak>0){
    // Currently being rejected: never claim authenticated, however recent the
    // last success was.
    state='stale';
  }else if(novaLastGoodDiscoveryAt&&sinceGood<NOVA_SESSION.staleAfterMs){
    state='authenticated';
  }else if(novaLastGoodDiscoveryAt){
    state='stale';
  }else{
    state='starting';
  }
  return{
    state,
    hasTokens,
    hasCookies,
    tokenAgeMs:_0xr&&_0xr.updatedAt?now-_0xr.updatedAt:null,
    sinceLastGoodDiscoveryMs:sinceGood,
    authFailStreak:novaAuthFailStreak,
    lastAuthIssue:novaLastAuthIssue,
    at:now
  };
};
const novaPublishSessionHealth=async(force)=>{
  const h=novaComputeSessionHealth();
  if(h.state!==novaSessionState||force){
    const previous=novaSessionState;
    novaSessionState=h.state;
    _0xn({kind:'nova_trace',event:'SESSION_HEALTH',sessionState:h.state,previous,
      hasTokens:h.hasTokens,hasCookies:h.hasCookies,tokenAgeMs:h.tokenAgeMs,
      sinceLastGoodDiscoveryMs:h.sinceLastGoodDiscoveryMs,authFailStreak:h.authFailStreak,
      lastAuthIssue:h.lastAuthIssue});
    if(h.state==='login_required'||h.state==='signed_out')_0xo('session_login_required');
  }
  await _0xm({sessionHealth:h});
  return h;
};
const novaNoteDiscoveryOk=()=>{
  novaLastGoodDiscoveryAt=Date.now();
  novaAuthFailStreak=0;
  novaLastAuthIssue=null;
  novaPublishSessionHealth(false);
};
const novaNoteDiscoveryAuthIssue=(kind)=>{
  novaAuthFailStreak++;
  novaLastAuthIssue=kind||null;
  novaPublishSessionHealth(false);
};

const novaEnsureWorker=async()=>{
  if(await novaTabAlive(novaWorkerTabId))return novaWorkerTabId;
  if(novaWorkerEnsuring)return novaWorkerEnsuring;
  const p=(async()=>{
    let id=novaWorkerTabId;
    if(!(await novaTabAlive(id)))id=await novaLoadWorkerId();
    if(!(await novaTabAlive(id)))id=null;
    if(id==null){
      const tab=await chrome.tabs.create({url:NOVA_IDLE_URL,active:false});
      id=tab.id;
      _0xo('worker_tabs_created');
      novaTrace('WORKER_TAB_CREATED',{tabId:id});
    }
    novaWorkerTabId=id;
    await novaSaveWorkerId(id);
    await novaKeepWorkerResident(id);
    return id;
  })();
  novaWorkerEnsuring=p.finally(()=>{novaWorkerEnsuring=null;});
  return novaWorkerEnsuring;
};

const novaResetWorkerToIdle=async(reason)=>{
  novaWorkerBusy=false;
  novaManualHold=false;
  if(!(await novaTabAlive(novaWorkerTabId))){
    novaWorkerTabId=null;
    novaTrace('WORKER_RESET_SKIPPED',{reason,detail:'no_live_worker'});
    return;
  }
  try{
    const id=novaWorkerTabId;
    await chrome.tabs.update(id,{url:NOVA_IDLE_URL,active:false});
    novaTrace('WORKER_RESET_IDLE',{reason,tabId:id});
  }catch(e){
    novaWorkerTabId=null;
    novaTrace('WORKER_RESET_FAILED',{reason,err:e&&e.message});
  }
};

const novaArmCandidateWatchdog=()=>{
  clearTimeout(novaCandidateTimer);
  novaCandidateTimer=setTimeout(()=>{
    novaCandidateTimer=null;
    if(!novaActiveCandidate)return;
    if(novaManualHold){novaArmCandidateWatchdog();return;}
    novaTrace('TIMEOUT',{reason:'candidate_watchdog'});
    _0xo('apply_timeouts');
    novaFinishCandidate('TIMEOUT');
  },NOVA_CFG.candidateTimeoutMs);
};

const novaFinishCandidate=async(outcome)=>{
  const c=novaActiveCandidate;
  clearTimeout(novaCandidateTimer);
  novaCandidateTimer=null;
  novaActiveCandidate=null;
  novaWorkerBusy=false;
  novaManualHold=false;
  try{await _0xl({[NOVA_ACTIVE_KEY]:null});}catch(e){}
  if(c){
    _0xn({kind:'nova_trace',event:'CANDIDATE_FINISHED',outcome,jobId:c.jobId,scheduleId:c.scheduleId,totalMs:Date.now()-c.detectedAt,firstActionMs:c.firstActionMs||null});
    _0xm({lastOutcome:{outcome,jobId:c.jobId,scheduleId:c.scheduleId,totalMs:Date.now()-c.detectedAt,firstActionMs:c.firstActionMs||null,at:Date.now()}});
  }
  if(outcome==='APPLICATION_SUCCESS'&&NOVA_CFG.stopQueueOnSuccess&&novaQueue.length){
    novaTrace('QUEUE_CLEARED',{reason:'application_success',dropped:novaQueue.length});
    novaQueue=[];
  }
  await novaResetWorkerToIdle(outcome);
  novaPumpQueue();
};

const novaPumpQueue=async()=>{
  if(novaQueuePumping||novaWorkerBusy||novaActiveCandidate)return;
  if(!novaQueue.length)return;
  if(_0x1x){novaTrace('QUEUE_HELD',{reason:'paused',depth:novaQueue.length});return;}
  if(!_0x2c()){novaQueue=[];return;}
  novaQueuePumping=true;
  try{
    const c=novaQueue.shift();
    if(!c)return;
    novaActiveCandidate=c;
    novaWorkerBusy=true;
    const url=novaApplyUrl(c.jobId,c.scheduleId);
    c.url=url;
    novaTrace('WORKER_NAVIGATION_REQUESTED',{url,queueDepth:novaQueue.length});
    let id;
    try{id=await novaEnsureWorker();}
    catch(e){
      novaTrace('WORKER_ENSURE_FAILED',{err:e&&e.message});
      _0xo(_nfbaa15(43));
      novaQueuePumping=false;
      await novaFinishCandidate('WORKER_UNAVAILABLE');
      return;
    }
    try{
      await _0xl({[NOVA_ACTIVE_KEY]:{jobId:c.jobId,scheduleId:c.scheduleId,detectedAt:c.detectedAt,url,tabId:id}});
      await chrome.tabs.update(id,{url,active:NOVA_CFG.focusOnHit});
      _0x1c=Date.now();
      _0xo('worker_navigations');
      novaArmCandidateWatchdog();
      _0x26({type:_nfbaa15(41),payload:{ok:true,candidate:{jobId:c.jobId,scheduleId:c.scheduleId},via:'worker'}});
    }catch(e){
      novaTrace('WORKER_NAVIGATION_FAILED',{err:e&&e.message});
      _0xo(_nfbaa15(43));
      novaWorkerTabId=null;
      novaQueuePumping=false;
      await novaFinishCandidate('WORKER_NAVIGATION_FAILED');
      return;
    }
  }finally{novaQueuePumping=false;}
};

const novaEnqueue=(jobId,scheduleId,meta)=>{
  meta=meta||{};
  const key=`${jobId}:${scheduleId}`;
  if(novaActiveCandidate&&novaActiveCandidate.key===key)return false;
  if(novaQueue.some(c=>c.key===key))return false;
  novaQueue.push({key,jobId,scheduleId,detectedAt:meta.detectedAt||Date.now(),jobTitle:meta.jobTitle||null,firstActionMs:null,enteredApplication:false});
  if(novaQueue.length>NOVA_CFG.maxQueue)novaQueue.splice(0,novaQueue.length-NOVA_CFG.maxQueue);
  novaPumpQueue();
  return true;
};

const novaMaintainWorker=async()=>{
  if(novaWorkerBusy||novaManualHold||novaActiveCandidate)return;
  if(_0x1x||!_0x2c())return;
  if(!_0xr&&!_0xy.present)return;
  if(Date.now()-novaLastWorkerMaintain<NOVA_CFG.workerMaintainMs)return;
  novaLastWorkerMaintain=Date.now();
  try{
    const id=await novaEnsureWorker();
    await novaKeepWorkerResident(id);
  }catch(e){}
  novaPublishSessionHealth(false);
};

const novaRestoreWorker=async()=>{
  novaWorkerBusy=false;
  novaManualHold=false;
  novaActiveCandidate=null;
  novaQueue=[];
  clearTimeout(novaCandidateTimer);
  novaCandidateTimer=null;
  const id=await novaLoadWorkerId();
  if(await novaTabAlive(id)){
    novaWorkerTabId=id;
    _0xn({kind:'nova_trace',event:'WORKER_TAB_RESTORED',tabId:id});
  }else{
    novaWorkerTabId=null;
  }
  try{await _0xl({[NOVA_ACTIVE_KEY]:null});}catch(e){}
};

chrome.tabs.onRemoved.addListener((tabId)=>{
  if(tabId!==novaWorkerTabId)return;
  novaWorkerTabId=null;
  novaSaveWorkerId(null);
  _0xn({kind:'nova_trace',event:'WORKER_TAB_CLOSED',tabId});
  if(novaWorkerBusy||novaActiveCandidate)novaFinishCandidate('WORKER_TAB_CLOSED');
});

chrome.tabs.onUpdated.addListener((tabId,info,tab)=>{
  if(tabId!==novaWorkerTabId)return;
  const c=novaActiveCandidate;
  if(!novaWorkerBusy||!c)return;
  const u=info.url||(tab&&tab.url)||'';
  if(info.status==='loading')novaTrace('WORKER_NAVIGATION_COMMITTED',{url:u});
  if(info.status==='complete')novaTrace('WORKER_DOM_AVAILABLE',{url:u});
  if(!u)return;
  if(/\/application\//.test(u)){c.enteredApplication=true;return;}
  if(novaManualHold)return;
  if(c.enteredApplication&&u.startsWith(`https://${_0x2}/`)&&u!==NOVA_IDLE_URL){
    novaTrace('RACE_LOST',{reason:'redirected_out_of_application',url:u});
    _0xo('races_lost');
    novaFinishCandidate('RACE_LOST');
  }
});

/* Entry point kept at the original name/shape so NOVA_FIRE_NOW and the poll
 * loop call it unchanged. It now queues onto the worker instead of creating
 * a tab. */
const _0x1d=async(_0x41,_0x42,_0x43={})=>{
  if(!_0x2c()){_0xn({kind:_nfbaa15(36),reason:_nfbaa15(37),jobId:_0x41,scheduleId:_0x42});return{ok:false,reason:_nfbaa15(37)};}
  const _0x44=`${_0x41}:${_0x42}`;
  if(_0x1a.has(_0x44)&&!_0x43.force)return{ok:false,reason:_nfbaa15(38)};
  _0x1a.add(_0x44);
  const detectedAt=_0x43.detectedAt||Date.now();
  const queued=novaEnqueue(_0x41,_0x42,{detectedAt,jobTitle:_0x43.jobTitle});
  if(!queued)return{ok:false,reason:'duplicate_candidate'};
  _0xo(_nfbaa15(39));
  _0xn({kind:'nova_trace',event:'SCHEDULE_DETECTED',jobId:_0x41,scheduleId:_0x42,jobTitle:_0x43.jobTitle||null,queueDepth:novaQueue.length,sinceDetectMs:0});
  return{ok:true,via:'worker',queued:true};
};
let _0x1e=0;let _0x1f=0;let _0x1g=false;let _0x1h=0;let _0x1i=0;const _0x1j=()=>Date.now()<_0x1f;const _0x1k=()=>{_0x1e++;if(_0x1e>=_0xd){_0x1f=Date.now()+_0xe;_0xn({kind:_nfbaa15(46),streak:_0x1e,note:_nfbaa15(47)});_0xm({breaker:{tripped:true,until:_0x1f}});_0xo(_nfbaa15(48));_0x1e=0;}};const _0x1l=()=>{if(_0x1e>0)_0x1e=0;if(_0x1f&&Date.now()>=_0x1f){_0x1f=0;_0xm({breaker:{tripped:false,until:0}});}};const _0x1m=(_0x48=new Date())=>{const _0x49=_0x48.getUTCFullYear();const _0x4a=String(_0x48.getUTCMonth()+1).padStart(2,_nfbaa15(49));const _0x4b=String(_0x48.getUTCDate()).padStart(2,_nfbaa15(49));return`${_0x49}-${_0x4a}-${_0x4b}`;};const _0x1n=async _0x4c=>{const _0x4d={searchScheduleRequest:{locale:_0x4,country:_0x3,jobId:_0x4c,pageSize:100,consolidateSchedule:true}};const _0x4e=await _0x11(_nfbaa15(50),_0xj,_0x4d);if(_0x4e.error){_0xn({kind:_nfbaa15(51),jobId:_0x4c,..._0x4e});return{error:_0x4e.error,cards:[]};}const _0x4f=_0x4e.data?.searchScheduleCards?.scheduleCards||_0x4e.data?.searchScheduleCards?.schedules||[];return{cards:_0x4f};};
/* ============ Nova discovery: jobs and schedules tracked separately ========= *
 * The fast searchJobCardsByLocation query is unchanged. What changed is that a
 * job ID which already existed at startup is still re-checked for schedules, so
 * a brand-new scheduleId on an old job is detectable. scheduleCount from the
 * job card is used as a free, zero-extra-request signal; a slow safety-net
 * re-check covers the case where scheduleCount lags.
 * ========================================================================== */
/* LOCATION FILTER: DISABLED.
 * Every job returned by the existing searchJobCardsByLocation query is
 * eligible for schedule lookup, queueing and application, regardless of
 * city/province. Nova no longer rejects any opportunity on location grounds.
 * To re-enable filtering later, set NOVA_LOCATION_FILTER to an array such as
 * [{city:'london',state:'on'}] — leaving it null means "everything is eligible". */
const NOVA_LOCATION_FILTER=null;
const NOVA_DISCOVERY={
  // Availability-driven tier: a job whose card reports shifts is probed fast.
  scheduleRecheckHotMs:1500,
  hotMinGapMs:150,          // spacing inside an availability burst
  maxHotPerTick:3,          // cap on burst dispatches per poll tick
  // Safety net: rotating sweep for jobs whose card reports no shifts, in case
  // Amazon's scheduleCount lags. Oldest-checked first, strictly rate-capped so
  // the cost does NOT scale with how many jobs are being tracked.
  scheduleRecheckColdMs:60000,
  coldMinGapMs:900,
  maxColdPerTick:1,
  coldGuaranteeEveryTicks:5,  // reserve a tick for the sweep so a long run of
                              // available jobs cannot starve it indefinitely
  scheduleMaxInflight:2,
  jobStaleMs:30*60000,
  maxTrackedJobs:400
};
const novaNorm=(v)=>String(v==null?'':v).toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,' ').trim();
const novaNormCity=(v)=>novaNorm(v).replace(/^(?:saint|ste|st)\s+/,'st ');
const novaNormState=(v)=>{const s=novaNorm(v);return s==='ontario'?'on':s;};
/* Returns true for every job unless an explicit filter has been configured. */
const novaIsEligible=(card)=>{
  if(!NOVA_LOCATION_FILTER||!NOVA_LOCATION_FILTER.length)return true;
  const c=novaNormCity(card&&card.city);
  const st=novaNormState(card&&card.state);
  if(!c)return true;
  return NOVA_LOCATION_FILTER.some(p=>p.city===c&&(!p.state||!st||p.state===st));
};
const novaKnownJobs=new Map();
let novaScheduleInflight=0;
let novaTickCounter=0;
let novaLastScheduleReqAt=0;
const novaPruneJobs=(now)=>{
  for(const [id,rec] of novaKnownJobs){
    if(now-rec.lastSeen>NOVA_DISCOVERY.jobStaleMs)novaKnownJobs.delete(id);
  }
  if(novaKnownJobs.size>NOVA_DISCOVERY.maxTrackedJobs){
    const sorted=[...novaKnownJobs.entries()].sort((a,b)=>a[1].lastSeen-b[1].lastSeen);
    const drop=novaKnownJobs.size-NOVA_DISCOVERY.maxTrackedJobs;
    for(let i=0;i<drop;i++)novaKnownJobs.delete(sorted[i][0]);
  }
};

const novaCheckSchedules=(rec,reason)=>{
  novaScheduleInflight++;
  rec.checking=true;
  rec.lastScheduleCheck=Date.now();
  novaLastScheduleReqAt=rec.lastScheduleCheck;
  (async()=>{
    try{
      const {cards}=await _0x1n(rec.jobId);
      for(const card of cards||[]){
        if(!card||!card.scheduleId)continue;
        if(_0x17(card.scheduleId))continue;
        _0x16(card.scheduleId);
        _0xo(_nfbaa15(71));
        _0xn({kind:_nfbaa15(72),jobId:rec.jobId,scheduleId:card.scheduleId,jobTitle:rec.jobTitle,city:rec.city,state:rec.state,trigger:reason||null});
        await _0x1d(rec.jobId,card.scheduleId,{detectedAt:Date.now(),jobTitle:rec.jobTitle});
      }
    }catch(e){
      _0xn({kind:'nova_trace',event:'SCHEDULE_CHECK_ERROR',jobId:rec.jobId,err:e&&e.message});
    }finally{
      novaScheduleInflight--;
      rec.checking=false;
    }
  })();
};
const _0x1o=async()=>{novaMaintainWorker();const _0x4g=await _0xq();_0xo(_nfbaa15(52));const _0x4h={searchJobRequest:{locale:_0x4,country:_0x3,pageSize:100,sorters:[{fieldName:_nfbaa15(53),ascending:_nfbaa15(29)}],dateFilters:[{key:_nfbaa15(54),range:{startDate:_0x1m()}}]}};const _0x4i=await _0x11(_nfbaa15(55),_0xi,_0x4h);if(_0x4i.error){_0xn({kind:_nfbaa15(56),..._0x4i});if(_0x4i.error===_nfbaa15(31)){_0x1g=true;novaNoteDiscoveryAuthIssue(_0x4i.error);await _0x10();_0x1k();_0x24();_0xv();await _0xp(_0x4g,_0xy.present?_nfbaa15(31):_nfbaa15(57),_0xy.present?_nfbaa15(58):_nfbaa15(59));return;}if(_0x4i.error===_nfbaa15(32)){_0x1g=true;_0x1h=Date.now();_0x1k();_0x24();await _0xp(_0x4g,_nfbaa15(60),_nfbaa15(61));return;}if(_0x4i.error===_nfbaa15(23)||_0x4i.error===_nfbaa15(24)){novaNoteDiscoveryAuthIssue(_0x4i.error);await _0xp(_0x4g,_nfbaa15(57),_nfbaa15(59));return;}if(_0x4i.error===_nfbaa15(30)){await _0xp(_0x4g,_nfbaa15(62),_nfbaa15(63));return;}await _0xp(_0x4g,_nfbaa15(64),_nfbaa15(65));return;}_0x1l();novaNoteDiscoveryOk();if(_0x1g){_0x1g=false;await _0xp(_0x4g,_nfbaa15(66),_nfbaa15(67));}
const _0x4j=_0x4i.data?.searchJobCardsByLocation?.jobCards||[];
const now=Date.now();
const watched=[];
for(const card of _0x4j){
  if(!card||!card.jobId)continue;
  _0x18(card.jobId);
  if(!novaIsEligible(card))continue;
  const prev=novaKnownJobs.get(card.jobId);
  const rec=prev||{jobId:card.jobId,firstSeen:now,lastScheduleCheck:0,scheduleCount:null,checking:false};
  rec.prevScheduleCount=prev?prev.scheduleCount:null;
  rec.scheduleCount=typeof card.scheduleCount==='number'?card.scheduleCount:null;
  rec.jobTitle=card.jobTitle||rec.jobTitle||null;
  rec.city=card.city;
  rec.state=card.state;
  rec.lastSeen=now;
  novaKnownJobs.set(card.jobId,rec);
  watched.push(rec);
}
novaPruneJobs(now);
if(!_0x1b){
  _0x1b=true;
  _0xn({kind:_nfbaa15(69),count:_0x4j.length,watched:watched.length,note:'schedules are NOT seeded away'});
}
/* Two tiers. The availability signal on the job card is the fast path and
 * costs nothing extra; the rotating sweep is a strictly capped safety net so
 * total request volume does not grow with the number of tracked jobs. */
const hotDue=[];
const coldDue=[];
for(const r of watched){
  if(r.checking)continue;
  const known=r.scheduleCount!=null;
  const available=!known||r.scheduleCount>0;
  const grew=r.prevScheduleCount!=null&&r.scheduleCount!=null&&r.scheduleCount>r.prevScheduleCount;
  const appeared=r.prevScheduleCount===0&&r.scheduleCount>0;
  const neverChecked=r.lastScheduleCheck===0;
  if(available&&(grew||appeared||neverChecked||now-r.lastScheduleCheck>=NOVA_DISCOVERY.scheduleRecheckHotMs)){
    r.hotReason=grew?'count_increased':(appeared?'count_zero_to_positive':(neverChecked?'new_available_job':'hot_recheck'));
    hotDue.push(r);
  }else if(!available&&now-r.lastScheduleCheck>=NOVA_DISCOVERY.scheduleRecheckColdMs){
    coldDue.push(r);
  }
}
// Freshest availability signal first, then longest-unchecked.
hotDue.sort((a,b)=>(b.scheduleCount||0)-(a.scheduleCount||0)||a.lastScheduleCheck-b.lastScheduleCheck);
coldDue.sort((a,b)=>a.lastScheduleCheck-b.lastScheduleCheck);
let dispatched=0,hotSent=0,coldSent=0;
novaTickCounter++;
// Every Nth tick the sweep goes first, so persistent availability elsewhere
// cannot permanently block discovery of a job whose card count is lagging.
const coldFirst=coldDue.length>0&&novaTickCounter%NOVA_DISCOVERY.coldGuaranteeEveryTicks===0;
if(coldFirst){
  for(const rec of coldDue){
    if(coldSent>=NOVA_DISCOVERY.maxColdPerTick)break;
    if(novaScheduleInflight>=NOVA_DISCOVERY.scheduleMaxInflight)break;
    if(Date.now()-novaLastScheduleReqAt<NOVA_DISCOVERY.coldMinGapMs)break;
    novaCheckSchedules(rec,'safety_net_reserved');
    coldSent++;dispatched++;
  }
}
for(const rec of hotDue){
  if(hotSent>=NOVA_DISCOVERY.maxHotPerTick)break;
  if(novaScheduleInflight>=NOVA_DISCOVERY.scheduleMaxInflight)break;
  if(Date.now()-novaLastScheduleReqAt<NOVA_DISCOVERY.hotMinGapMs)break;
  novaCheckSchedules(rec,rec.hotReason||'hot');
  hotSent++;dispatched++;
}
for(const rec of coldFirst?[]:coldDue){
  if(coldSent>=NOVA_DISCOVERY.maxColdPerTick)break;
  if(novaScheduleInflight>=NOVA_DISCOVERY.scheduleMaxInflight)break;
  if(Date.now()-novaLastScheduleReqAt<NOVA_DISCOVERY.coldMinGapMs)break;
  novaCheckSchedules(rec,'safety_net');
  coldSent++;dispatched++;
}
await _0xp(_0x4g,dispatched?_nfbaa15(73):_nfbaa15(70),`${_0x4j.length} jobs · ${watched.length} tracked · ${hotSent}h/${coldSent}c sched · q${novaQueue.length}`);
};const _0x1p=(_0x4t,_0x4u)=>_0x4t+Math.floor(Math.random()*(_0x4u-_0x4t+1));const _0x1q=20000;const _0x1r=40000;let _0x1s=null;const _0x1t=()=>{if(_0x1s)return;const _0x4v=async()=>{const _0x4w=Date.now()-_0x1h<60000;if(!_0x1x&&_0x2c()&&!_0x4w){_0x24();_0xv();_0xn({kind:_nfbaa15(74)});}_0x1s=setTimeout(_0x4v,_0x1p(_0x1q,_0x1r));};_0x1s=setTimeout(_0x4v,_0x1p(_0x1q,_0x1r));};const _0x1u=async()=>{await _0xv();const _0x4x=await _0x11(_nfbaa15(55),_0xi,{searchJobRequest:{locale:_0x4,country:_0x3,pageSize:1}});if(_0x4x.error===_nfbaa15(32)){_0x1h=Date.now();return false;}return!_0x4x.error;};let _0x1v=null;let _0x1w=0;let _0x1x=false;const _0x1y=async()=>{const {[_0x1.paused]:_0x4y=false}=await _0xk([_0x1.paused]);_0x1x=!!_0x4y;};const _0x1z=async _0x4z=>{_0x1x=!!_0x4z;await _0xl({[_0x1.paused]:_0x1x});await _0xm({paused:_0x1x});};const _0x20=()=>{if(_0x1v)return;const _0x50=async()=>{if(_0x1x){if(Date.now()-_0x1w>15000){_0x1w=Date.now();const {[_0x1.pollCount]:_0x51=0}=await _0xk([_0x1.pollCount]);await _0xp(_0x51,_nfbaa15(75),_nfbaa15(76));}_0x1v=setTimeout(_0x50,2000);return;}if(!_0x2c()){if(Date.now()-_0x1w>15000){_0x1w=Date.now();const _0x52=_0x27?.reason||_nfbaa15(77);const {[_0x1.pollCount]:_0x53=0}=await _0xk([_0x1.pollCount]);await _0xp(_0x53,_nfbaa15(78),`paused — license ${_0x52}`);}_0x1v=setTimeout(_0x50,5000);return;}if(_0x1j()){const _0x54=Math.max(0,Math.round((_0x1f-Date.now())/1000));const {[_0x1.pollCount]:_0x55=0}=await _0xk([_0x1.pollCount]);const _0x56=Date.now()-_0x1h<60000;if(!_0x56&&Date.now()-_0x1i>30000){_0x1i=Date.now();const _0x57=await _0x1u();if(_0x57){_0x1f=0;_0x1e=0;_0x1g=false;_0xm({breaker:{tripped:false,until:0}});await _0xp(_0x55,_nfbaa15(66),_nfbaa15(79));_0x1v=setTimeout(_0x50,200);return;}}await _0xp(_0x55,_nfbaa15(80),`Paused to protect account — retrying in ${_0x54}s`);_0x1v=setTimeout(_0x50,5000);return;}await _0x1o();_0x1v=setTimeout(_0x50,_0x1p(_0x7,_0x8));};_0x1v=setTimeout(_0x50,100);};const _0x21=()=>{if(_0x1v){clearTimeout(_0x1v);_0x1v=null;}};let _0x22=null;const _0x23=()=>{clearTimeout(_0x22);const _0x58=_0x1p(_0x9,_0xa);_0x22=setTimeout(async()=>{const _0x59=Date.now()-_0x1c;if(_0x59<_0xb){_0xn({kind:_nfbaa15(81),reason:_nfbaa15(82),sinceApplyMs:_0x59});}else if(novaWorkerBusy||novaActiveCandidate||novaManualHold){_0xn({kind:_nfbaa15(81),reason:'worker_busy'});}else if(!_0x1x&&_0x2c()){chrome.tabs.query({url:`https://${_0x2}/*`},async _0x5a=>{const _0x5b=(_0x5a||[]).find(_0x5c=>_0x5c.id!==novaWorkerTabId&&!/\/application\//.test(_0x5c.url||''));if(_0x5b){chrome.tabs.reload(_0x5b.id).catch(()=>{});_0xo(_nfbaa15(83));_0xn({kind:_nfbaa15(84),tabId:_0x5b.id});const {[_0x1.pollCount]:_0x5d=0}=await _0xk([_0x1.pollCount]);await _0xp(_0x5d,_nfbaa15(60),_nfbaa15(85));}});}_0x23();},_0x58);};const _0x24=()=>{chrome.tabs.query({url:`https://${_0x2}/*`},_0x5e=>{if(!_0x5e?.length)return;const _0x5e2=_0x5e.filter(t=>t.id!==novaWorkerTabId);const _0x5e3=_0x5e2.length?_0x5e2[0]:((novaWorkerBusy||novaActiveCandidate)?null:_0x5e[0]);if(!_0x5e3)return;chrome.tabs.sendMessage(_0x5e3.id,{type:_nfbaa15(86)}).catch(()=>{});});};const _0x25=(()=>{let _0x5f=null;return()=>{clearTimeout(_0x5f);_0x5f=setTimeout(async()=>{await _0x10();await _0xv();_0xn({kind:_nfbaa15(87),cookiesPresent:_0xy.present});},150);};})();try{chrome.cookies.onChanged.addListener(_0x5g=>{const _0x5h=_0x5g?.cookie;if(!_0x5h)return;if(!/(^|\.)hiring\.amazon\.ca$/.test(_0x5h.domain)&&!/(^|\.)amazon\.ca$/.test(_0x5h.domain))return;if(!_0xz.test(_0x5h.name))return;_0x25();});}catch(_0x5i){}const _0x26=_0x5j=>{chrome.tabs.query({url:`https://${_0x2}/*`},_0x5k=>{for(const _0x5l of _0x5k||[])chrome.tabs.sendMessage(_0x5l.id,_0x5j).catch(()=>{});});};let _0x27=null;let _0x28=null;const _0x29=async()=>{const {[_0x1.installId]:_0x5m}=await _0xk([_0x1.installId]);if(_0x5m)return _0x5m;const _0x5n=self.crypto?.randomUUID?.()||`iid-${Date.now()}-${Math.random().toString(36).slice(2)}`;await _0xl({[_0x1.installId]:_0x5n});return _0x5n;};const _0x2a=async()=>{const {[_0x1.licenseCfg]:_0x5o={}}=await _0xk([_0x1.licenseCfg]);const _0x5p=_0x0.replace(/\/+$/,'');return{server:_0x5p,key:_0x5o.key||''};};const _0x2b=async()=>{const {[_0x1.license]:_0x5q=null}=await _0xk([_0x1.license]);_0x27=_0x5q;};const _0x2c=()=>{if(!_0x27)return false;if(_0x27.valid){if(_0x27.expiry&&Date.now()>new Date(_0x27.expiry).getTime())return false;return true;}if(_0x27.reason===_nfbaa15(30)&&_0x27.lastValidAt&&Date.now()-_0x27.lastValidAt<_0xh)return true;return false;};const _0x2d=async _0x5r=>{_0x27={..._0x27||{},..._0x5r};await _0xl({[_0x1.license]:_0x27});_0xm({license:{valid:!!_0x27.valid,reason:_0x27.reason||null,expiry:_0x27.expiry||null}});};const _0x2e=async()=>{const _0x5s=await _0x2a();if(!_0x5s.key){await _0x2d({valid:false,reason:_nfbaa15(77),checkedAt:Date.now()});return _0x27;}const _0x5t=await _0x29();const _0x5u=(self.navigator?.userAgent||_nfbaa15(88)).slice(0,300);const _0x5v=_0xr?.bbCandidateId||'';try{const _0x5w=await fetch(`${_0x5s.server}/v1/validate`,{method:_nfbaa15(25),headers:{'content-type':_nfbaa15(28)},body:JSON.stringify({license_key:_0x5s.key,install_id:_0x5t,system:_0x5u,candidate_id:_0x5v})});let _0x5x={};try{_0x5x=await _0x5w.json();}catch(_0x5y){}if(_0x5w.ok&&_0x5x.valid){_0xn({kind:_nfbaa15(89),expiry:_0x5x.expiry||null});await _0x2d({valid:true,reason:_nfbaa15(70),expiry:_0x5x.expiry||null,checkedAt:Date.now(),lastValidAt:Date.now()});}else{const _0x5z=_0x5x.reason||(_0x5w.status===404?_nfbaa15(90):_nfbaa15(91));_0xn({kind:_nfbaa15(92),reason:_0x5z,status:_0x5w.status});await _0x2d({valid:false,reason:_0x5z,expiry:_0x5x.expiry||null,checkedAt:Date.now()});}}catch(_0x60){_0xn({kind:_nfbaa15(93),err:_0x60?.message});await _0x2d({valid:false,reason:_nfbaa15(30),checkedAt:Date.now()});}return _0x27;};const _0x2f=async()=>{await _0x2b();await _0x2e();if(_0x28)clearInterval(_0x28);_0x28=setInterval(_0x2e,_0xg);};chrome.runtime.onInstalled.addListener(()=>_0x2g());chrome.runtime.onStartup.addListener(()=>_0x2g());const _0x2g=async()=>{await _0xs();await _0x1y();await _0x10();await _0x2f();await novaRestoreWorker();await novaPublishSessionHealth(true);chrome.alarms.clearAll(()=>chrome.alarms.create(_nfbaa15(94),{periodInMinutes:1}));_0x20();_0x1t();_0x23();};chrome.alarms.onAlarm.addListener(async _0x61=>{if(_0x61?.name!==_nfbaa15(94))return;_0x20();_0x1t();_0xv();novaMaintainWorker();});setInterval(()=>_0xv(),_0xf);chrome.runtime.onMessage.addListener((_0x62,_0x63,_0x64)=>{(async()=>{switch(_0x62?.type){case _nfbaa15(95):{const _0x65=await _0x2a();_0x64({serverConfigured:true,server:_0x65.server,key:_0x65.key||'',license:_0x27?{..._0x27,active:_0x2c()}:null});return;}case _nfbaa15(96):{const _0x66=await _0x2a();const _0x67={key:typeof _0x62.key===_nfbaa15(97)?_0x62.key.trim():_0x66.key};await _0xl({[_0x1.licenseCfg]:_0x67});const _0x68=await _0x2e();_0x20();_0x64({ok:true,license:_0x68?{..._0x68,active:_0x2c()}:null});return;}case _nfbaa15(98):{const _0x69=await _0x2e();_0x64({ok:true,license:_0x69?{..._0x69,active:_0x2c()}:null});return;}case _nfbaa15(99):await _0xu(_0x62.tokens);_0x64({ok:true});return;case _nfbaa15(100):await _0xm({signedIn:!!_0x62.ok});if(!_0x62.ok)novaNoteDiscoveryAuthIssue("content_signed_out");await novaPublishSessionHealth(false);_0x64({ok:true});return;case _nfbaa15(101):{const _0x6a=_0x62.stage||_nfbaa15(88);_0xn({kind:`apply_${_0x6a}`,url:_0x62.url});if(_0x6a===_nfbaa15(102))_0xo(_nfbaa15(103));else if(_0x6a===_nfbaa15(104))_0xo(_nfbaa15(105));_0x64({ok:true});return;}case 'NOVA_APPLY_EVENT':{
  const ev=_0x62.event||'UNKNOWN';
  const c=novaActiveCandidate;
  const rec={kind:'nova_trace',event:ev,url:_0x62.url,uiState:_0x62.state,detail:_0x62.detail||null,label:_0x62.label||null,testId:_0x62.testId||null,tMs:_0x62.t};
  if(c){rec.jobId=c.jobId;rec.scheduleId=c.scheduleId;rec.sinceDetectMs=Date.now()-c.detectedAt;}
  _0xn(rec);
  const stale=c&&_0x62.scheduleId&&String(_0x62.scheduleId)!==String(c.scheduleId);
  if(stale){_0x64({ok:true,ignored:'stale_candidate'});return;}
  if(ev==='DOM_AVAILABLE'){if(c)c.enteredApplication=true;}
  else if(ev==='ACTION_CLICKED'){
    _0xo(_nfbaa15(103));
    if(c&&!c.firstActionMs){
      c.firstActionMs=Date.now()-c.detectedAt;
      _0xo('first_action_total_ms',c.firstActionMs);
      _0xo('first_action_samples');
      await _0xm({lastFirstActionMs:c.firstActionMs});
      _0xn({kind:'nova_trace',event:'FIRST_VALID_APPLICATION_ACTION',jobId:c.jobId,scheduleId:c.scheduleId,elapsedMs:c.firstActionMs,label:_0x62.label||null});
    }
  }
  else if(ev==='APPLICATION_SUCCESS'){
    _0xo('applications_succeeded');
    await _0xm({lastSuccess:{jobId:c?c.jobId:null,scheduleId:c?c.scheduleId:null,at:Date.now(),firstActionMs:c?c.firstActionMs:null}});
    await novaFinishCandidate('APPLICATION_SUCCESS');
  }
  else if(ev==='RACE_LOST'){
    _0xo('races_lost');
    await novaFinishCandidate('RACE_LOST');
  }
  else if(ev==='MANUAL_ACTION_REQUIRED'){
    _0xo('manual_actions_required');
    novaManualHold=true;
    clearTimeout(novaCandidateTimer);
    novaCandidateTimer=null;
    try{if(novaWorkerTabId!=null)await chrome.tabs.update(novaWorkerTabId,{active:true});}catch(e){}
    await _0xm({manualAction:{at:Date.now(),url:_0x62.url||null,detail:_0x62.detail||null}});
  }
  else if(ev==='MANUAL_ACTION_RESOLVED'){
    if(novaManualHold){novaManualHold=false;novaArmCandidateWatchdog();}
    await _0xm({manualAction:null});
  }
  else if(ev==='TIMEOUT'){
    _0xo(_nfbaa15(105));
    await novaFinishCandidate('TIMEOUT');
  }
  else if(ev==='UNKNOWN_PAGE'){
    _0xo('unknown_pages');
    await _0xm({lastUnknownPage:{at:Date.now(),url:_0x62.url||null,diagnostics:_0x62.diagnostics||null}});
  }
  _0x64({ok:true});
  return;
}
case 'NOVA_WORKER_STATUS':{
  _0x64({ok:true,worker:{tabId:novaWorkerTabId,busy:novaWorkerBusy,manualHold:novaManualHold,queueDepth:novaQueue.length,active:novaActiveCandidate?{jobId:novaActiveCandidate.jobId,scheduleId:novaActiveCandidate.scheduleId,detectedAt:novaActiveCandidate.detectedAt,firstActionMs:novaActiveCandidate.firstActionMs}:null,trackedJobs:novaKnownJobs.size},sessionHealth:novaComputeSessionHealth()});
  return;
}
case 'NOVA_RESET_WORKER':{
  await novaFinishCandidate('MANUAL_RESET');
  _0x64({ok:true,tabId:novaWorkerTabId});
  return;
}
case _nfbaa15(106):{const [{[_0x1.status]:_0x6b={}},{[_0x1.metrics]:_0x6c={}},{[_0x1.pollLog]:_0x6d=[]},{[_0x1.pollCount]:_0x6e=0}]=await Promise.all([_0xk([_0x1.status]),_0xk([_0x1.metrics]),_0xk([_0x1.pollLog]),_0xk([_0x1.pollCount])]);_0x64({status:_0x6b,metrics:_0x6c,pollLog:_0x6d,pollCount:_0x6e,paused:_0x1x,signedIn:!!_0x6b.signedIn,breaker:{tripped:_0x1j(),until:_0x1f},worker:{tabId:novaWorkerTabId,busy:novaWorkerBusy,manualHold:novaManualHold,queueDepth:novaQueue.length,trackedJobs:novaKnownJobs.size},sessionHealth:novaComputeSessionHealth(),license:_0x27?{valid:!!_0x27.valid,reason:_0x27.reason,expiry:_0x27.expiry,active:_0x2c()}:null});return;}case _nfbaa15(107):{await _0x1z(!!_0x62.paused);if(!_0x1x){_0x20();_0x1t();}_0x64({ok:true,paused:_0x1x});return;}case _nfbaa15(108):{const _0x6f=await _0x1d(_0x62.jobId,_0x62.scheduleId,{force:true});_0x64({ok:_0x6f.ok,via:_nfbaa15(42),..._0x6f});return;}case _nfbaa15(109):_0x1o();_0x64({ok:true});return;case _nfbaa15(110):await _0xl({[_0x1.pollLog]:[]});_0x64({ok:true});return;default:_0x64({ok:false});}})().catch(_0x6g=>_0x64({ok:false,message:_0x6g?.message}));return true;});_0x2g();